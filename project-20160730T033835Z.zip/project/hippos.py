'''Hippo classes for HHH
Created on Dec 1, 2014
CS108 Final Project
@author: Lia Gelder (leg4)
'''

from tkinter import *
from hippofood import *
from gameboard import *
        
class Hippo:
    def chomp(self, canvas, gameboard):
        for i in range(1, 11):
            self.head_up(canvas)
            canvas.after(50)
            canvas.update()
            self.check_gobble(gameboard.get_ball_list(), canvas)
        for i in range(1, 3):
            self.head_down(canvas)
            canvas.after(50)
            canvas.update()   
             
    def check_gobble(self, balllist, canvas):
        for b in balllist:
            if distance(b.getx(), b.gety(), self.snoutx + 50, self.snouty + 30) < 25 and self.is_head_up:
                balllist.remove(b)
                self.score += 1
                if b.getx() > 350:
                    canvas.delete("rscore")
                    canvas.create_text(self.scorex, self.scorey, text="Score = " + str(self.score), tags="rscore")
                elif b.getx() < 350:
                    canvas.delete("lscore")
                    canvas.create_text(self.scorex, self.scorey, text="Score = " + str(self.score), tags="lscore")


class LeftHippo(Hippo):
    def __init__(self, canvas, x, y, color):
        self.x = x
        self.y = y
        self.color = color
        self.score = 0
        canvas.create_oval(self.x + 10, self.y + 300, self.x + 160, self.y + 400, fill=self.color, outline=self.color, tags="lbody")
        canvas.create_rectangle(self.x + 100, self.y + 325, self.x + 200, self.y + 375, fill=self.color, outline=self.color, tags="lneck")
        canvas.create_oval(self.x + 175, self.y + 310, self.x + 250, self.y + 390, fill=self.color, outline=self.color, tags="lhead")
        canvas.create_rectangle(self.x + 200, self.y + 320, self.x + 300, self.y + 380, fill=self.color, outline=self.color, tags="lsnout")
        canvas.create_text(self.x + 50, self.y + 275, text="Press 'Q' \nto chomp")
        canvas.create_text(self.x + 50, self.y + 425, text="Score = 0", tags="lscore")
        self.scorex = self.x + 50
        self.scorey = self.y + 425
        self.headx = self.x + 175
        self.heady = self.y + 310
        self.snoutx = self.x + 200
        self.snouty = self.y + 320
        
    def head_up(self, canvas):
        canvas.delete("lsnout")
        canvas.delete("lhead")
        canvas.create_oval(self.headx, self.heady, self.headx + 50, self.heady + 80, fill="yellow", outline="yellow", tags="lhead")
        canvas.create_rectangle(self.snoutx, self.snouty, self.snoutx + 50, self.snouty + 60, fill="yellow", outline="yellow", tags="lsnout")
        self.is_head_up = True
        
    def head_down(self, canvas):
        canvas.delete("lhead")
        canvas.delete("lsnout")
        canvas.create_oval(self.headx, self.heady, self.headx + 75, self.heady + 80, fill="yellow", outline="yellow", tags="lhead")
        canvas.create_rectangle(self.snoutx, self.snouty, self.snoutx + 100, self.snouty + 60, fill="yellow", outline="yellow", tags="lsnout" )
        self.is_head_up = False
        
class RightHippo(Hippo):
    def __init__(self, canvas, x, y, color):
        self.color = color
        self.x = x
        self.y = y
        self.score = 0
        canvas.create_oval(self.x + 540, self.y + 300, self.x + 690, self.y + 400, fill=self.color, outline=self.color, tags="rbody")
        canvas.create_rectangle(self.x + 500, self.y + 325, self.x + 600, self.y + 375, fill=self.color, outline=self.color, tags="rneck")
        canvas.create_oval(self.x + 450, self.y + 310, self.x + 525, self.y + 390, fill=self.color, outline=self.color, tags="rhead")
        canvas.create_rectangle(self.x + 400, self.y + 320, self.x + 500, self.y + 380, fill=self.color, outline=self.color, tags="rsnout")
        canvas.create_text(self.x + 650, self.y + 275, text="Press 'M' \nto chomp")
        canvas.create_text(self.x + 650, self.y + 425, text="Score = 0", tags="rscore")
        self.scorex = self.x + 650
        self.scorey = self.y + 425
        self.headx = self.x + 450
        self.heady = self.y + 310
        self.snoutx = self.x + 400
        self.snouty = self.y + 320
        
    def head_up(self, canvas):
        canvas.delete("rsnout")
        canvas.delete("rhead")
        canvas.create_oval(self.headx+ 25, self.heady , self.headx + 75, self.heady + 80, fill=self.color, outline=self.color, tags="rhead")
        canvas.create_rectangle(self.snoutx + 50, self.snouty, self.snoutx + 100, self.snouty + 60, fill=self.color, outline=self.color, tags="rsnout")
        self.is_head_up = True
    
    def head_down(self, canvas):
        canvas.delete("rhead")
        canvas.delete("rsnout")
        canvas.create_oval(self.headx, self.heady, self.headx + 75, self.heady + 80, fill=self.color, outline=self.color, tags="rhead")
        canvas.create_rectangle(self.snoutx, self.snouty, self.snoutx + 100, self.snouty + 60, fill=self.color, outline=self.color, tags="rsnout" )
        self.is_head_up = False
     
     
class TopHippo:
    def __init__(self, canvas):
        canvas.create_oval(300, 10, 400, 160, fill="orange", outline="orange", tags="body")
        canvas.create_rectangle(325, 100, 375, 200, fill="orange", outline="orange", tags="neck")
        canvas.create_oval(310, 175, 390, 275, fill="orange", outline="orange", tags="head")
        canvas.create_text(260, 50, text="Press 'P' \nto chomp")
      
      
class BottomHippo:
    def __init__(self, canvas):
        canvas.create_oval(300, 540, 400, 690, fill="green", outline="green", tags="body")
        canvas.create_rectangle(325, 500, 375, 600, fill="green", outline="green", tags="neck")
        canvas.create_oval(310, 425, 390, 525, fill="green", outline="green", tags="head")
        canvas.create_text(260, 650, text="Press 'C' \nto chomp")
     
     
     
     
     
     
     
if __name__ == "__main__":    
    window = Tk()
    window.geometry("+200+0")
    canvas = Canvas(window, bg="red", width=700, height=700)
    canvas.pack()
    
    board = GameBoard(canvas)
    #board.begin(canvas)
     
    l = LeftHippo(canvas, 0, 0, "yellow")
    r = RightHippo(canvas, 0, 0, "pink")

    terminate = False
    while not terminate:
        l.chomp(canvas, board)
        r.chomp(canvas, board)
         
    board.begin(canvas)
#     TopHippo(canvas)
#     BottomHippo(canvas)
#     while True:
#         l.head_up(canvas)
#         canvas.after(1000)
#         canvas.update()
#         r.head_up(canvas)
#         canvas.after(1500)
#         canvas.update()
#         l.head_down(canvas)
#         canvas.after(500)
#         canvas.update()
#         r.head_down(canvas)
#         canvas.after(500)
#         canvas.update()
    
   
    
    
    window.mainloop()

    
        
        