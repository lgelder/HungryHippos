'''Hungry Hungry Hippos
Created on Dec 1, 2014
CS108 Final Project
@author: Lia Gelder (leg4)
'''

from tkinter import *
from hippos import *
from hippofood import *
from gameboard import *

class HungryHungryHippos:
    def __init__(self):
        self.window = Tk()
        self.window.title("Hungry Hungry Hippos!")
        self.window.protocol('WM_DELETE_WINDOW', self.exitClean)
        self.window.geometry("+400+0")
        self.window.configure(bg="red")
        self.startmessage = Label(self.window, bg="red", fg="white", text="Welcome to Hungry Hungry Hippos!\nTo begin, click on the number of players!")
        self.startmessage.pack()
        self.frame1 = Frame(self.window, bg="red")
        self.frame1.pack()
        self.startlbl = Label(self.frame1, bg="red", fg="white", text="How many players?")
        self.startlbl.pack(side=LEFT)
        self.twoplayers = Button(self.frame1, bg="white", fg="red", text="Two", command=self.begin_game2)
        #self.threeplayers = Button(self.frame1, bg="white", fg="red", text="Three", command=self.begin_game3)
        #self.fourplayers = Button(self.frame1, bg="white", fg="red", text="Four", command=self.begin_game4)
        self.twoplayers.pack(side=LEFT)
        #self.threeplayers.pack(side=LEFT)
        #self.fourplayers.pack(side=LEFT)
        self.terminate = False
        self.window.mainloop()
        
#     def choose_color(self):
#         self.startmessage.destroy() #learned destroy on stackOverflow
#         self.startlbl.destroy()
#         self.twoplayers.destroy()
#         self.colormessage = Label(self.window, bg="red", fg="white", text="Choose a color for Hippo 1:")
#         self.yellowbt = Button(self.frame1, bg="yellow", text="Yellow", command=self.selectyellow)
#         self.pinkbt = Button(self.frame1, bg="pink", text="Pink", command=self.selectpink)
        
    def begin_game2(self):
        self.startmessage.destroy() #learned destroy on stackOverflow
        self.startlbl.destroy()
        self.twoplayers.destroy()
        self.frame1.destroy()
        self.canvas = Canvas(self.window, bg="red", width=700, height=700)
        self.canvas.pack()
        self.board = GameBoard(self.canvas)
        self.lefty = LeftHippo(self.canvas, 0, 0, "yellow")
        self.righty = RightHippo(self.canvas, 0, 0, "pink")
        self.canvas.focus_set()
        self.canvas.bind("<q>", self.lchomp)
        self.canvas.bind("<m>", self.rchomp)
        self.canvas.bind("<y>", self.drop_balls)
              
    def drop_balls(self, event):
        self.board.begin(self.canvas)
         
    def lchomp(self, event):
        self.lefty.chomp(self.canvas, self.board)
         
    def rchomp(self, event):
        self.righty.chomp(self.canvas, self.board)
    
    def exitClean(self):
        self.terminate = True
        self.board.terminate = True
        self.canvas.delete(ALL)
        self.window.destroy()
            
#     def begin_game3(self):
#         self.startmessage.destroy() #learned destroy on stackOverflow
#         self.startlbl.destroy()
# #         self.firstentry.destroy()
# #         self.startbt.destroy()
#         self.frame1.destroy()
#         self.canvas = Canvas(self.window, bg="red", width=700, height=700)
#         self.canvas.pack()
#         GameBoard(self.canvas)
#         LeftHippo(self.canvas)
#         RightHippo(self.canvas)
#         BottomHippo(self.canvas)

#     def begin_game4(self):
#         self.startmessage.destroy() #learned destroy on stackOverflow
#         self.startlbl.destroy()
# #         self.firstentry.destroy()
# #         self.startbt.destroy()
#         self.frame1.destroy()
#         self.canvas = Canvas(self.window, bg="red", width=700, height=700)
#         self.canvas.pack()
#         GameBoard(self.canvas)
#         LeftHippo(self.canvas)
#         RightHippo(self.canvas)
#         BottomHippo(self.canvas)
#         TopHippo(self.canvas)  
HungryHungryHippos()

