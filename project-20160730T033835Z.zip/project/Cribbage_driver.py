'''Cribbage Game
Created on Nov 20, 2014

@author: Lia Gelder
'''


# from tkinter import *
# from cribbage_funcs import *
# 
# class Cribbage_Game:
#     def __init__(self):
#         self.window = Tk()
#         self.window.title("Let's Play Cribbage!")
#         self.canvas = Canvas(self.window, width=600, height=300)
#         CBoard = Cribbage_board(self.canvas, 50, 50)
#         self.canvas.pack()
# 
#         
#         
#         self.window.mainloop()
#         
#         
# Cribbage_Game()

# from cribbage_game import Card
# 
# 
# class CardHand:
#     def __init__(self, card1, card2, card3, card4, card5=0, card6=0):
#         self.hand = [card1, card2, card3, card4, card5, card6]
#         
#     def removeCard(self, card):
#         self.hand.remove(card)
#                
#     def addCard(self, card):
#         self.hand.append(card)
#     
#     def __str__(self):
#         result = ""
#         for card in self.hand:
#             result += str(card) + " "
#         return result 
#    
#     
#     
#     
# card1 = Card(5, "Heart")
# card2 = Card(4, "Heart")
# card3 = Card(3, "heart")
# card4 = Card(7, "club")
# card5 = Card(9, "spade")
# card6 = Card(13, "diamond")
# 
# hand = CardHand(card1, card2, card3, card4, card5, card6)
# 
# 
# 
# print(hand)




from tkinter import *

# class Key_Event_Demo:
#     def __init__(self):
#         window = Tk()
#         window.title("Key Events")
#         window.geometry('+100+100')
#         
#         canvas = Canvas(window, bg='white',
#                         width = 300, height = 200)
#         canvas.pack()
#         
#         canvas.bind("<Key>", self.processKeyEvent)   
#         canvas.focus_set() 
#         window.mainloop()
#     
#     def processKeyEvent(self, event):
#         print("keysym?", event.keysym)
#         print("char?", event.char)
#         print("keycode?", event.keycode)
# 
# Key_Event_Demo()


class CanvasDemo:
    def __init__(self):
        window = Tk()
        window.title("Canvas Demo")
        
        self.canvas = Canvas(window, width = 600, height = 600, bg = 'white')
        self.canvas.pack()
        self.canvas.create_rectangle(50, 50, 500, 400, 
                                     tags = 'rect', 
                                     fill = 'white', activefill='blue')
        self.canvas.create_oval(10, 10, 500, 250, 
                                fill = 'red', tags = 'oval')
        self.canvas.create_arc(100, 300, 400, 400, 
                               start=0, extent=90, width=8, 
                               fill = 'blue', tags='arc')
        self.canvas.create_polygon(200, 500, 
                                   500, 500, 
                                   400, 300, 
                                   350, 400,  
                                   fill="green")
        self.canvas.create_line(450, 30, 
                                470, 490, width = 9, 
                                arrow='last', 
                                activefill = 'blue', tags='line')
        self.canvas.create_text(250, 425, 
                                text = "ABCDE" , 
                                fill = 'purple', activefill='blue')

        drawHouse(self.canvas, 50, 500)
        window.mainloop()
        
def drawHouse(canvas, x, y):
    # canvas.delete('oval')
    canvas.create_rectangle(x, y, x+50, y+50, fill='brown')
    canvas.create_polygon(x, y, x+25, y-25, x+50, y, fill='black')
    canvas.create_rectangle(x+20, y+30, x+30, y+50, fill='navy')
    canvas.create_arc(x+10, y+10, x+40, y+30, start=0, extent=180,fill='white')
        
        
CanvasDemo()















