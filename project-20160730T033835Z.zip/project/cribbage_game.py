'''the game of cribbage
Created on Nov 22, 2014
cs108 final project
@author: Lia Gelder (leg4)
'''

import random
from tkinter import *

class Card:
    def __init__(self, number, suit):
        '''(int, str) -> Card
        Constructor'''
        if 1 <= number <= 13:
            self._number = number
        else:
            print("Not a valid card number")
        suit = suit.upper()
        if suit == 'SPADE' or suit == 'HEART' or suit == 'CLUB' or suit == 'DIAMOND':
            self._suit = suit
        else:
            print("Not a valid suit")
    
    def get_number(self):
        '''accessor for number'''
        return self._number
    
    def get_suit(self):
        '''accessor for suit'''
        return self._suit
        
    def __eq__(self, other): 
        '''overloading the equality operator'''
        if self._number == other.get_number():
            return True 
        else:
            return False
            
    def __gt__(self, other):
        '''overloading the greater than operator'''
        if self._number == 1 and other.get_number() != 1:
            return True
        elif other.get_number() == 1 and self._number != 1:
            return False
        elif self._number == 1 and other.get_number() == 1:
            return False       
        elif self._number > other.get_number():
            return True
        elif self._number < other.get_number():
            return False
            
    def __lt__(self, other):
        '''overloading the less than operator'''
        if self._number == 1 and other.get_number != 1:
            return False
        elif other.get_number() == 1 and self._number != 1:
            return True
        elif self._number == other.get_number():
            return False
        elif self._number < other.get_number():
            return True
        elif self._number > other.get_number():
            return False
           
    def __str__(self):
        '''prints Card objects nicely'''
        if 1 < self._number < 11:
            return (str(self._number) + self._suit[0])
        elif self._number == 1:
            return ("A" + self._suit[0])
        elif self._number == 11:
            return ("J" + self._suit[0])
        elif self._number == 12:
            return ("Q" + self._suit[0])
        elif self._number == 13:
            return ("K" + self._suit[0])



class CribbageGUI:
    def __init__(self):
        self.window = Tk()
        self.window.title("Let's Play Cribbage!")
        self.window.geometry("+300+100")
        self.yourhand = StringVar()
        self.comphand = StringVar()
        self.crib = StringVar()
        startbt = Button(self.window, text="Begin Playing!", command=self.open_game)
        startbt.pack()
    
        self.window.mainloop()
        
    def open_game(self):
        Deck = []
        numlist = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13]
        suitlist = ["Heart", "Diamond", "Spade", "Club"]
        for i in numlist:
            for s in suitlist:
                Deck.append(Card(i, s))
        
        intlist = []
        comphand = []
        for i in range(1,7):
            randnum = random.randint(0, 51)
            while randnum in intlist:
                randnum = random.randint(0, 51)
            comphand.append(Deck[randnum])
            intlist.append(randnum)
        
        playhand = []
        for i in range(1,7):
            randnum = random.randint(0, 51)
            while randnum in intlist:
                randnum = random.randint(0, 51)
            playhand.append(Deck[randnum])
            intlist.append(randnum)
        
        crib = []
        
        rnum1 = random.randint(0, 5)
        rnum2 = random.randint(0, 5)
        while rnum1 == rnum2:
            rnum1 = random.randint(0, 5)
        card1 = comphand[rnum1]
        card2 = comphand[rnum2]
        crib.append(card1)
        crib.append(card2)
        comphand.remove(card1)
        comphand.remove(card2)
        
        self.yourhand = playhand
        self.comphand = comphand
        self.crib = crib
        
        yourhandlbl = Label(self.window, textvariable=self.yourhand)
        yourhandlbl.pack()
        
        comphandlbl = Label(self.window, textvariable=self.comphand)
        comphandlbl.pack()
        
        criblbl = Label(self.window, textvariable=self.crib)
        criblbl.pack()
        
        
        
        
        

    
            
        
#-----------Main Code------------
if __name__ == "__main__":
    CribbageGUI()


        



# print("Please choose two cards to put in the crib. Your cards are: ", end="")
# for i in playhand:
#     print(i, "", end="")
# print(". \nEnter a number (1-6) to indicate your first choice: ", end="")
# choice1 = int(input())
# print("Please enter a number (1-6) to indicate your second choice: ", end="")
# choice2 = int(input())
# 
# choice1 = playhand[choice1-1]
# choice2 = playhand[choice2-1]
# 
# 
# crib.append(choice1)
# crib.append(choice2)
# 
# playhand.remove(choice1)
# playhand.remove(choice2)
# 
# print("Crib = ", end="")
# for i in crib:
#     print(i, "", end="")
#     
# print("your hand = ", end="")
# for i in playhand:
#     print(i, '', end="")
# 
# print("computer's hand = ", end="")
# for i in comphand:
#     print(i, '', end="")




