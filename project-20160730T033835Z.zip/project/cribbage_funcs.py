
from tkinter import *

class Cribbage_board:
    def __init__(self, canvas, x, y):
        canvas.create_rectangle(x,y,x+440,y+150, fill="brown")
        oldx = x
        for n in range(x,x+400,20):
            canvas.create_oval(x+25, y+5, x+35, y+15, fill="black")
            canvas.create_oval(x+25, y+20, x+35, y+30, fill="black")
            canvas.create_oval(x+25, y+40, x+35, y+50, fill="black")
            canvas.create_oval(x+25, y+60, x+35, y+70, fill="black")
            canvas.create_oval(x+25, y+85, x+35, y+95, fill="black")
            canvas.create_oval(x+25, y+100, x+35, y+110, fill="black")
            canvas.create_oval(x+25, y+120, x+35, y+130, fill="black")
            canvas.create_oval(x+25, y+ 135, x+35, y+145, fill="black")
            x += 20
        canvas.create_oval(oldx+5, y+5, oldx+15, y+15, fill="black")
        canvas.create_oval(oldx+5, y+20, oldx+15, y+30, fill="black")
        canvas.create_oval(oldx+5, y+120, oldx+15, y+130, fill="black")
        canvas.create_oval(oldx+5, y+135, oldx+15, y+145, fill="black")
        canvas.create_line(oldx+30, y+35, oldx+400, y+35, arrow="last")
        canvas.create_line(oldx+30, y+77, oldx+400, y+77, arrow="first")
        canvas.create_line(oldx+30, y+115, oldx+400, y+115, arrow="last")
        canvas.create_line(oldx+20, y, oldx+20, y+150)
        canvas.create_line(oldx+120, y, oldx+120, y+150)
        canvas.create_line(oldx+220, y, oldx+220, y+150)
        canvas.create_line(oldx+320, y, oldx+320, y+150)
        canvas.create_line(oldx+420, y, oldx+420, y+150)
        canvas.create_arc(180,90,54,65)

if __name__ =="__main__":
    window = Tk()
    canvas = Canvas(window, width=600, height=300)
    canvas.pack()
    CBoard = Cribbage_board(canvas, 50, 50)
    window.mainloop()
        