'''Gameboard for HHH
Created on Dec 4, 2014
CS108 Final Project
@author: Lia Gelder (leg4)
'''

import hippofood
from hippos import *
from helpers import distance

class GameBoard:
    def __init__(self, canvas):
        canvas.create_oval(125, 125, 575, 575)
        self.balllist = []
        for i in range(1, 11):
            ball = hippofood.HippoChow()
            self.balllist.append(ball)
        canvas.create_rectangle(0, 0, 100, 50, fill="white", tags="beginmsg")
        canvas.create_text(50, 25, text="Press 'Y' to begin.", tags="beginmsg")
        self.terminate = False
        
    def get_ball_list(self):
        return self.balllist

    def begin(self, canvas):
        while not self.terminate:
            canvas.delete("food")
            for b in self.balllist:
                b.move(canvas)
                b.render(canvas)
                for b2 in self.balllist:
                    b.bounce(b2)
            canvas.after(50)
            canvas.update()
        
        