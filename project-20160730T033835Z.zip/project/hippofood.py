'''Ball (hippofood) class for HHH
Created on Dec 2, 2014
CS108 Final Project
@author: Lia Gelder (leg4)
'''

from helpers import distance
import math
from tkinter import *
import random
from hippos import *
from gameboard import *

DAMPENING_FACTOR = 0.88

class HippoChow: #modified from the Particle class from lab
    def __init__(self):
        self.x = 350
        self.y = 350
        self.velX = random.randint(1, 10)
        self.velY = random.randint(1, 10)
        self.radius = 10
        self.color = "white"
        
    def render(self, canvas):
        canvas.create_oval(self.x - self.radius, self.y - self.radius,self.x + self.radius,self.y + self.radius, fill = self.color, tags="food")
        
    def move(self, canvas):
        self.x += self.velX
        self.y += self.velY 
        if distance(self.x + self.radius, self.y + self.radius, 350, 350) > 200:
            self.velX *= -1
            self.velY *= -1
        elif distance(self.x - self.radius, self.y - self.radius, 350, 350) > 200:
            self.velX *= -1
            self.velY *= -1
#         if self.x + self.radius > 700 or self.x - self.radius < 0:
#             self.velX *= -1
#         if self.y + self.radius > 700 or self.y - self.radius < 0:
#             self.velY *= -1
        
    def getx(self):
        '''accessor for x'''
        return self.x
    
    def gety(self):
        '''accessor for y'''
        return self.y
    
    def getrad(self):
        '''accessor for radius'''
        return self.radius
    
 
    def hits(self, other):
        if (self == other):
            # I can't collide with myself.
            return False
        else:
            # Determine if I overlap with the target particle.
            return (self.radius + other.getrad()) >= distance(self.x, self.y, other.getx(), other.gety())
            
     
    def bounce(self, target):
        ''' This method modifies this Particle object's velocities based on its
            collision with the given target particle. It modifies both the magnitude
            and the direction of the velocities based on the interacting magnitude
            and direction of particles. It only changes the velocities of this
            object; an additional call to bounce() on the other particle is required
            to implement a complete bounce interaction.
      
            The collision algorithm is based on a similar algorithm published by K.
            Terzidis, Algorithms for Visual Design.
      
            target = the other particle
         '''
        if self.hits(target):
            angle = math.atan2(target.gety() - self.y, target.getx() - self.x)
            targetX = self.x + math.cos(angle) * (self.radius + target.getrad())
            targetY = self.y + math.sin(angle) * (self.radius + target.getrad())
            ax = targetX - target.getx()
            ay = targetY - target.gety()
            self.velX = (self.velX - ax) * DAMPENING_FACTOR
            self.velY = (self.velY - ay) * DAMPENING_FACTOR
#             self.velX /= 1.25
#             self.velY /= 1.25
            
            
            
if __name__ == "__main__":         
    window = Tk()
    canvas = Canvas(window, bg="red", width=700, height=700)
    canvas.pack()
    balllist = []
    for i in range(1, 11):
        ball = HippoChow()
        balllist.append(ball)
    board = GameBoard(canvas)
    
    while True:
        canvas.delete("food")
        for b in balllist:
            b.move(canvas)
            b.render(canvas)
            for b2 in balllist:
                b.bounce(b2)
        canvas.after(100)
        canvas.update()
    
    window.mainloop()






















